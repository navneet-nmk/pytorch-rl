import opensim
from osim.env import ProstheticsEnv
env = ProstheticsEnv()



